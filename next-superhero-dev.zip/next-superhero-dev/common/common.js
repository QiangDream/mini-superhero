const serverUrl = "https://www.imovietrailer.com/superhero";			// 生产环境
// const serverUrl = "https://www.imovietrailer-dev.com/superhero";		// 开发环境

export default{
	serverUrl
}